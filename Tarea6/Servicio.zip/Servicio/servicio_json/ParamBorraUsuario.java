/*
  Carlos Pineda Guerrero, noviembre 2022
*/

package servicio_json;

import com.google.gson.*;

public class ParamBorraUsuario 
{
  String email;
}
