/*
  Carlos Pineda Guerrero, noviembre 2022
*/

package servicio_json;

import com.google.gson.*;

import servicio_json.Articulo;

public class ParamModificaArticulo 
{
  int id_articulo;
  int cantidad;
}
