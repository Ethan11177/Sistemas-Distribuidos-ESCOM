/*
  Carlos Pineda Guerrero, noviembre 2022
*/

package servicio_json;

import com.google.gson.*;


public class ParamBorrarArticulo 
{
  int id_articulo;
  int cantidad;
  double precio;
  byte[] foto;
  String nombre;
}
