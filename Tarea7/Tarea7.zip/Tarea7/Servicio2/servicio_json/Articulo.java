
package servicio_json;

import java.sql.Timestamp;

public class Articulo {
    int id_articulo;
    String nombre;
    String descripcion;
    double precio;
    int cantidad;
    byte[] foto;
}
